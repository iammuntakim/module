#!/system/bin/sh

find_misc() {
  for p in /dev/block/by-name/misc \
           /dev/block/bootdevice/by-name/misc \
           /dev/block/platform/*/by-name/misc \
           /dev/block/platform/*/*/by-name/misc; do
    [ -b "$p" ] && echo "$p" && return 0
  done
  find /dev/block -name "misc" 2>/dev/null | head -n 1
}

MISC=$(find_misc)
[ -n "$MISC" ] && [ -b "$MISC" ] || exit 0

C=$(dd if="$MISC" bs=1024 count=2 2>/dev/null | strings)

case "$C" in
  *boot-recovery*|*wipe_data*|*master_clear*|*factory_reset*)
    sleep 0.1
    CONFIRM=$(dd if="$MISC" bs=1024 count=2 2>/dev/null | strings)
    if [ "$C" = "$CONFIRM" ]; then
      dd if=/dev/zero of="$MISC" bs=2048 count=1 conv=notrunc 2>/dev/null
      echo -n "boot-system0" | dd of="$MISC" bs=1 seek=0 count=12 conv=notrunc 2>/dev/null
      sync
    fi
  ;;
esac
