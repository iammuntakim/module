#!/system/bin/sh
MISC=/dev/block/by-name/misc
[ -b "$MISC" ] || exit 0
C=$(dd if=$MISC bs=16 count=1 2>/dev/null | strings)
case "$C" in *recovery*|*wipe*|*reset*|*pm*)
  dd if=/dev/zero of=$MISC bs=1024 count=4 2>/dev/null
  echo -n "boot-system0" | dd of=$MISC bs=1 seek=0 count=12 2>/dev/null
;; esac